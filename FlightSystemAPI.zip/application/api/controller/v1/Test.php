<?php
/**
 * Created by MCY<1991993249@qq.com>
 * User: 勉成翌
 * Date: 2017/9/19
 * Time: 14:05
 */

namespace app\api\controller\v1;


class Test
{
    public function test(){
        return 'Test';
    }
}