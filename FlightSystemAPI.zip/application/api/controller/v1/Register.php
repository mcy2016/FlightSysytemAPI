<?php
/**
 * Created by MCY<1991993249@qq.com>
 * User: 勉成翌
 * Date: 2017/12/14
 * Time: 13:29
 */

namespace app\api\controller\v1;


use think\Controller;

class Register extends Controller
{
    public function regist()
    {

    }
}