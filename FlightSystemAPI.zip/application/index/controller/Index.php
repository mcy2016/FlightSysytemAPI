<?php

namespace app\index\controller;

class Index
{
    public function index()
    {
        return "<h1 style='text-align: center;color: red;'>
                Ameco贵阳分公司航班信息系统Api接口
                </h1>";
    }
}
