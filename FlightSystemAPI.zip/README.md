# FlightSysytemAPI
使用TP5开发的航班信息系统后台API（Ameco贵阳）
=======

## 根据日期获取航班信息API
> API接口url：/v1/plane
> Type:GET
> Param:d=2017-11-15

# 关于README.md文件会在后期编写和更新！

2018年4月20日